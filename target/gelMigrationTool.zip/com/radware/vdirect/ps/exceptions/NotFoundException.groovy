package com.radware.vdirect.ps.exceptions

class NotFoundException extends RuntimeException {
    NotFoundException(String msg) {
        super(msg)
    }
}
